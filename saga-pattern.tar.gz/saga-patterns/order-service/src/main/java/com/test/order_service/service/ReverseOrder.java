package com.test.order_service.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.test.order_service.dto.OrderEvent;

@Component
public class ReverseOrder {
    
    @KafkaListener(topics = "reversed-orders", groupId = "orders-group")
    public void reverseOrder(String event) throws Exception {

        System.out.println("Reverse Orders");

        OrderEvent orderEvent = new ObjectMapper().readValue(event, OrderEvent.class);

    }
}
