package com.test.order_service.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.order_service.dto.CustomerOrder;
import com.test.order_service.dto.OrderEvent;
import com.test.order_service.entity.Order;
import com.test.order_service.entity.OrderRepository;
import org.springframework.web.bind.annotation.PostMapping;


@RestController
@RequestMapping("/api")
public class OrderController {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private KafkaTemplate<String,OrderEvent> kafkaTemplate;


    @PostMapping("/orders")
    public void createOrder(@RequestBody CustomerOrder customerOrder) {
        
        // orders 테이블에 주문 정보 등록 (status)
        Order order = new Order();
        order.setItem(customerOrder.getItem());
        order.setAmount(customerOrder.getAmount());        
        order.setQuantity(customerOrder.getQuantity());
        order.setStatus("CREATED");
        orderRepository.save(order);

        // kafka에 OrderEvent 보내기
        // 파티션이 하나만 존재 (순차적으로 하나씩 출력)
        OrderEvent orderEvent = new OrderEvent();
        customerOrder.setId(order.getId());
        customerOrder.setStatus(order.getStatus());
        orderEvent.setOrder(customerOrder);
        orderEvent.setType("ORDER_CREATED");
        kafkaTemplate.send("new-orders", orderEvent);
        
    }

}
