drop DATABASE IF EXISTS deliverydb;
drop DATABASE IF EXISTS stockdb;
drop DATABASE IF EXISTS paymentsdb;
drop DATABASE IF EXISTS ordersdb;

create DATABASE deliverydb;
create DATABASE stockdb;
create DATABASE paymentsdb;
create DATABASE ordersdb;